package com.xm.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xm.pojo.User;
import com.xm.service.UserService;

@Controller
@RequestMapping("/mui")
//@CrossOrigin(origins = "*",maxAge = 3600)
public class Mui_LoginController {
		
	@Autowired
	UserService userService;
	
	@RequestMapping("/login")
	@ResponseBody
	public Map<String,String> mui_login(@RequestBody User user) {		
		//System.out.println(user.getUsername());
		
		Map<String, String> ret = new HashMap<String, String>();
		User existUser = userService.get(user);
		if(existUser == null) {
			ret.put("type", "error");
			ret.put("msg", "���û��������ڣ�");
			return ret;
		}
		if(!user.getPassword().equals(existUser.getPassword())) {
//			System.out.println(user.getPassword());
//			System.out.println(existUser.getPassword());
			ret.put("type", "error");
			ret.put("msg", "�������");
			return ret;
		}
		else
		{
			//�����û���session���ں����ȡ�û���Ϣ
			//request.getSession().setAttribute("username", existUser);
			String name=existUser.getUsername();
			//request.getSession().setAttribute("username2",name);
			ret.put("type", "success");
			ret.put("msg", "��¼�ɹ���");
			return ret;
		}
	}
	
}
