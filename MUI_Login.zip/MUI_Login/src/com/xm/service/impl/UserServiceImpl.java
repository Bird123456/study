package com.xm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xm.mapper.UserMapper;
import com.xm.pojo.User;
import com.xm.service.UserService;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserMapper userMapper;
	
	@Override
	public void add(User user) {
		// TODO Auto-generated method stub
		userMapper.add(user);
	}

	@Override
	public User get(User user) {
		// TODO Auto-generated method stub
		return userMapper.get(user);
	}

}
